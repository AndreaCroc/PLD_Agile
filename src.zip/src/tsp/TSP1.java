package tsp;

import java.util.ArrayList;
import java.util.Iterator;

public class TSP1 extends TemplateTSP implements TSP {

    @Override
    protected int bound(Integer sommetCourant, ArrayList<Integer> nonVus, Double[][] cout, Integer[] duree) {
        return 0;
    }

    @Override
    protected Iterator<Integer> iterator(Integer sommetCrt, ArrayList<Integer> nonVus, Double[][] cout, Integer[] duree) {
        System.out.println("TSP111111111111_-_-_-_-__-_-_-_-");
        System.out.println(sommetCrt);
        return new IteratorSeq1(nonVus, sommetCrt, cout);
    }


}
