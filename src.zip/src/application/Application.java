/*
 * Application
 *
 * Version 1
 *
 * 
 * Lucie BOVO, Andrea CROC, Sophie LABOUCHEIX, Taoyang LIU,
 * Alexanne MAGNIEN, Grazia RIBBENI, Fatoumata WADE
 *
 */
package application;

import Vue.Fenetre;
import controleur.Controleur;

public class Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Fenetre fenetre = new Fenetre();
        System.out.println("testSophie");
        new Controleur();
    }
    
}
